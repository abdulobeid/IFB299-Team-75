<?php
    // Start the session
    session_start();
?>

<?php

include("connect.php"); 
# Connect to the database


$conn = db_connect();

if (isset($_POST['fileID']) && isset($_POST['fileName']) && isset($_POST['fileType'])) {

	$sql = "UPDATE tableFiles SET columnName='".$_POST['fileName']."' WHERE columnID=".$_POST['fileID'];

	if ($conn->query($sql) === TRUE) {
		//echo "Record updated successfully";
	} else {
		//echo "Error updating record: " . $conn->error;
	}

	$sql = "UPDATE tableFiles SET columnType='".$_POST['fileType']."' WHERE columnID=".$_POST['fileID'];

	if ($conn->query($sql) === TRUE) {
		//echo "Record updated successfully";
	} else {
		//echo "Error updating record: " . $conn->error;
	}
	
	echo '<script type="text/javascript">'
	   , 'parent.updateFileStuff();'
	   , '</script>'
	;
}
	//header("Refresh:0");
	
	/*if(isset($_POST['delete'])){
    $queryDelete = "DELETE FROM tableFiles WHERE columnID=".$_POST['fileID'];
	$filename = "/var/www/html/uploads/{$_POST['fileName']}";
	echo $filename;
	if (unlink($filename)) {
		mysqli_query($conn, $queryDelete);
        echo 'File <strong>'.$filename.'</strong>has been deleted.';
        } else {
            echo 'File cannot be deleted.';
        }
    }*/

?>

<html>
<head>
	<meta charset="utf-8">
	<link href='https://fonts.googleapis.com/css?family=Orbitron' rel='stylesheet' type='text/css'>
	<link href='https://fonts.googleapis.com/css?family=Roboto' rel='stylesheet' type='text/css'>
	<link href="CSS/mainStyles.css" rel="stylesheet" type="text/css" />
	<link href="CSS/filterStyles.css" rel="stylesheet" type="text/css" />
</head>
<body>			

<div id="_div_BBR_IFR">

	<p>
	File Details 
	</p>
	
	<div id="_div_FTR_BOX">
		Filename: <attributeThing id="ATT_NME"> </attributeThing>
	<p>
		File Type: <attributeThing id="ATT_TYP"> </attributeThing>
	<p>
		Date Added: <attributeThing id="ATT_DTE"> </attributeThing>
	<br>
	</div>
	<div id="_div_FTR_BOX_VEW">
		<input onclick="clicked(Name)" value="Test">  
		<input id="_inp_BTN_2" type="submit" onclick=alertNotYet() value="View Online">  
		<input id="_inp_BTN_2" type="submit" onclick=downloadStuff() value="Download">
	</div>
	<p>
		File Editing
	</p>
	<form id="fileForm" action=fileForm.php method=post>
	<div id="_div_FTR_BOX">
		Update Filename:
		<p>
		<input name="fileName" id="_inp_TXT_2">
	</div>
	
	<div id="_div_FTR_BOX">
		Update File Color Tag:<p>
	
		<div name="INP_COL" class="_N_SEL" id="_inp_TAG_RED"  onclick="tagColSet('0',this)"></div>
		<div name="INP_COL" class="_N_SEL" id="_inp_TAG_ORANGE" onclick="tagColSet('1',this)"></div>
		<div name="INP_COL" class="_N_SEL" id="_inp_TAG_YELLOW" onclick="tagColSet('2',this)"></div>
		<div name="INP_COL" class="_N_SEL" id="_inp_TAG_GREEN" onclick="tagColSet('3',this)"></div>
		<div name="INP_COL" class="_N_SEL" id="_inp_TAG_AQUA" onclick="tagColSet('4',this)"></div>
		<div name="INP_COL" class="_N_SEL" id="_inp_TAG_NAVY" onclick="tagColSet('5',this)"></div>
		<div name="INP_COL" class="_N_SEL" id="_inp_TAG_PURPLE" onclick="tagColSet('6',this)"></div>
		<div name="INP_COL" class="_N_SEL" id="_inp_TAG_PINK" onclick="tagColSet('7',this)"></div>
		<div name="INP_COL" class="_SEL" id="_inp_TAG_NONE" onclick="tagColSet('8',this)"></div>
		<br><br>
	</div>
	
	
	<input type="hidden" name="fileID" >
	
	<input type="hidden" name="fileType" >
	<input id="_inp_BTN_2" type="submit" value="Save Details"></form>
		
	
	<form id="deleteForm" action=deleteFile.php method=post>
	<input name="fle_NME" type="hidden">
	<input name="fle_IDS" type="hidden">
	<input name="fle_ACT" type="hidden">
	<input id="_inp_BTN_DELETE" type="submit" onclick=deleteConfirmation() value="Delete File">
	</form>
	</div>
	<iframe id="my_iframe" style="display:none;"></iframe>

	<div id="light" class="white_content">This is the lightbox content. <a href = "javascript:void(0)" onclick = "document.getElementById('light').style.display='none';document.getElementById('fade').style.display='none'">Close</a>
	<img id = 'popImage' src = '#' alt='error' width='100%'></img>
	</div>
<div id="fade" class="black_overlay"></div>
</body>

<script>
	var FLE_NME_TAKE = "";
	function downloadStuff() {
		var win = window.open(FLE_NME_TAKE, '_blank');
		win.focus();
	}
	
	function deleteConfirmation() {
		if (confirm("Confirm that you wish to delete this file")) {
			document.deleteForm.submit();
			document.getElementsByName("fle_ACT")[0].value = "yes";
		} else {
			document.getElementsByName("fle_ACT")[0].value = "no";
		}
	}

	function setAttributesOf(IDS,Name,Type,Time,Colr,Rname) {
		document.getElementById("ATT_NME").innerHTML = Name;
		document.getElementById("ATT_TYP").innerHTML = Type;
		document.getElementById("ATT_DTE").innerHTML = Time;
		document.getElementById("_inp_TXT_2").value = Name;
		document.getElementsByName("fileID")[0].value = IDS;
		
		document.getElementsByName("fle_IDS")[0].value = IDS;
		document.getElementsByName("fle_NME")[0].value = Rname;
		FLE_NME_TAKE = Rname;
		document.getElementsByName("fileType")[0].value = Colr;
		tagColSetDifferent(Colr);
	}

	function tagColSetDifferent(col) { 
		for (i = 0; i <= 8; i ++) {
			document.getElementsByName("INP_COL")[i].className = "_N_SEL";
		}
		filterCOL = col;
		document.getElementsByName("INP_COL")[col].className = "_SEL";
	}
 
	function tagColSet(col,item) { 
		for (i = 0; i <= 8; i ++) {
			document.getElementsByName("INP_COL")[i].className = "_N_SEL";
		}
		filterCOL = col;
		item.className = '_SEL';
		document.getElementsByName("fileType")[0].value = col;
	}
 
	function alertNotYet() {
		window.alert("This feature has not yet been implemented. Stick around for the second release.");
	}

	function clicked(id){
		document.getElementById('light').style.display='block';
		document.getElementById('fade').style.display='block';
		document.getElementById("popImage").src = Name;
	}
</script>
